package com.app.ecommercestore;

import com.app.ecommercestore.model.Order;
import com.app.ecommercestore.model.Product;
import com.app.ecommercestore.model.Role;
import com.app.ecommercestore.model.User;
import com.app.ecommercestore.repository.OrderRepository;
import com.app.ecommercestore.repository.UserRepository;
import com.app.ecommercestore.service.OrderService;
import org.aspectj.weaver.ast.Or;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
class OrderServiceTest {
    @Autowired
    OrderService orderService;
    @MockBean
    OrderRepository orderRepository;

    @MockBean
    UserRepository userRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Test
    public void getAllOrdersTest() {
        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);

        List<Product> productList = new ArrayList<>();
        productList.add(product);

        Order order = new Order();
        order.setId(1L);
        order.setOrderDateTime(LocalDateTime.now());
        order.setProducts(productList);
        order.setTotalPrice(5000.0);

        List<Order> ordersList = new ArrayList<>();
        ordersList.add(order);
        when(orderRepository.findAll()).thenReturn(ordersList);
        assertEquals(ordersList, orderService.getAllOrders());
    }

    @Test
    public void getOrdersByUserTest() {
        Role role = new Role();
        role.setId(1L);
        role.setName("ROLE_USER");

        User user = new User();
        user.setFirstName("Test");
        user.setLastName("User");
        user.setAddress("Street 54, house #3, Islamabad, Pakistan");
        user.setEmail("test@gmail.com");
        user.setUsername("test_user");
        user.setPassword(bCryptPasswordEncoder.encode("password"));
        user.setRole(role);


        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);


        List<Product> productList = new ArrayList<>();
        productList.add(product);


        Order order = new Order(1L, LocalDateTime.now(), productList, 5000.0);

        List<Order> ordersList = new ArrayList<>();
        ordersList.add(order);

        user.setOrders(ordersList);

        when(userRepository.findUserByUsername("test_user")).thenReturn(Optional.of(user));
        assertEquals(user.getOrders(), orderService.getOrdersByUser("test_user"));
    }

    @Test
    public void getProductsByOrderTest() {
        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);
        List<Product> productList = new ArrayList<>();
        productList.add(product);
        Order order = new Order(1L, LocalDateTime.now(), productList, 5000.0);
        order.setProducts(productList);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        assertEquals(productList, orderService.getProductsByOrder(1L));
    }


    @Test
    public void getCustomerFromAnOrderTest() {
        Role role = new Role();
        role.setId(1L);
        role.setName("ROLE_USER");

        User user = new User();
        user.setFirstName("Test");
        user.setLastName("User");
        user.setAddress("Street 54, house #3, Islamabad, Pakistan");
        user.setEmail("test@gmail.com");
        user.setUsername("test_user");
        user.setPassword(bCryptPasswordEncoder.encode("password"));
        user.setRole(role);

        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);


        List<Product> productList = new ArrayList<>();
        productList.add(product);
        Order order = new Order(1L, LocalDateTime.now(), productList, 5000.0);

        List<Order> ordersList = new ArrayList<>();
        ordersList.add(order);
        user.setOrders(ordersList);

        List<User> userList = new ArrayList<>();
        userList.add(user);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(userRepository.findAll()).thenReturn(userList);
        assertEquals(user, orderService.getCustomerFromAnOrder(1L));
    }
}
