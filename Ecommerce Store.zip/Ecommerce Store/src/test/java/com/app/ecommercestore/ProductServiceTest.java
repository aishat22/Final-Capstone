package com.app.ecommercestore;

import com.app.ecommercestore.model.Product;
import com.app.ecommercestore.repository.ProductRepository;
import com.app.ecommercestore.service.ProductService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
class ProductServiceTest {

    @Autowired
    ProductService productService;

    @MockBean
    ProductRepository productRepository;

    @Test
    public void getProductByIdTest() {
        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);
        when(productRepository.getById(1L)).thenReturn(product);
        assertEquals(product, productService.getProductById(1L));
    }

    @Test
    public void getAllProductsTest() {
        Product product = new Product(1L, "Football", "The description of football", 5000.0, "football.jpg", false);

        List<Product> productList = new ArrayList<>();

        productList.add(product);
        when(productRepository.getAllProducts()).thenReturn(productList);
        assertEquals(productList, productService.getAllProducts());
    }
}
