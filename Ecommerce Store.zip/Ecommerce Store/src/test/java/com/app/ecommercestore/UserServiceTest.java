package com.app.ecommercestore;

import com.app.ecommercestore.model.Role;
import com.app.ecommercestore.model.User;
import com.app.ecommercestore.repository.UserRepository;
import com.app.ecommercestore.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
class UserServiceTest {

    @Autowired
    UserService userService;

    @MockBean
    UserRepository userRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Test
    public void saveUserTest() {
        Role role = new Role();
        role.setId(1L);
        role.setName("ROLE_USER");

        User user = new User();
        user.setFirstName("Test");
        user.setLastName("User");
        user.setAddress("Street 54, house #3, Islamabad, Pakistan");
        user.setEmail("test@gmail.com");
        user.setUsername("test_user");
        user.setPassword("password");
        user.setRole(role);

        when(userRepository.save(user)).thenReturn(user);
        assertEquals(user, userService.save(user));
    }

    @Test
    public void getUserByUsernameTest() {
        Role role = new Role();
        role.setId(1L);
        role.setName("ROLE_USER");
        User user = new User();
        user.setFirstName("Test");
        user.setLastName("User");
        user.setAddress("Street 54, house #3, Islamabad, Pakistan");
        user.setEmail("test@gmail.com");
        user.setUsername("test_user");
        user.setPassword("password");
        user.setRole(role);

        when(userRepository.findUserByUsername("test_user")).thenReturn(Optional.of(user));
        assertEquals(user, userService.getUserByUsername("test_user").get());
    }
}
