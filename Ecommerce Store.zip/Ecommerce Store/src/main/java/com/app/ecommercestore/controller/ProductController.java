package com.app.ecommercestore.controller;

import com.app.ecommercestore.model.Product;
import com.app.ecommercestore.service.CartService;
import com.app.ecommercestore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequestMapping("/product")
public class ProductController {
    @Autowired
    ProductService productService;

    @Autowired
    CartService cartService;

    /**
     * This api will be getting used view the page to add new products
     *
     * @param model
     * @return
     */
    @GetMapping("/new")
    public String getProductUploadForm(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "add-product";
    }

    /**
     * This api will be getting used to create/add new products in the database.
     *
     * @param product
     * @param multipartFile
     * @return
     * @throws IOException
     */
    @PostMapping("/save")
    public String saveUser(Product product, @RequestParam("image") MultipartFile multipartFile) throws IOException {
        productService.saveProduct(product, multipartFile);
        return "redirect:/admin/dashboard";
    }

    /**
     * This api will be getting used to view all the products that are in the database.
     *
     * @param model
     * @return
     */
    @GetMapping("/all")
    public String productsList(Model model) {
        model.addAttribute("productsList", productService.getAllUnDeletedProducts());
        model.addAttribute("cartItems", cartService.viewCart());
        return "customer-dashboard";
    }

    /**
     * This controller will show us the details of a single product.
     *
     * @param model
     * @param productId
     * @return
     */
    @GetMapping("/getById/{id}")
    public String getProductById(Model model, @PathVariable(name = "id") Long productId) {
        model.addAttribute("product", productService.getProductById(productId));
        return "view-product";
    }

    /**
     * This is getting used to delete a product from the frontend.
     *
     * @param productId
     * @return
     */
    @GetMapping("/deleteById/{id}")
    public String deleteProductById(@PathVariable(name = "id") Long productId) {
        productService.deleteProduct(productId);
        return "redirect:/admin/dashboard";
    }

    /**
     * This is getting used to update a product in the database.
     *
     * @param model
     * @param productId
     * @return
     */
    @GetMapping("/update/{id}")
    public String updateProduct(Model model, @PathVariable(name = "id") Long productId) {
        model.addAttribute("productId", productId);
        model.addAttribute("product", productService.getProductById(productId));
        return "update-product";
    }

    @PostMapping("/update/{id}")
    public String updateProduct(@PathVariable(name = "id") Long productId, Product product, @RequestParam("image") MultipartFile multipartFile) throws IOException {
        product.setId(productId);
        productService.saveProduct(product, multipartFile);
        return "redirect:/admin/dashboard";
    }
}
